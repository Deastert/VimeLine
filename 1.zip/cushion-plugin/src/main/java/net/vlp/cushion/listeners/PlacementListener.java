package net.vlp.cushion.listeners;

import net.vlp.cushion.CushionItemFactory;
import net.vlp.cushion.CushionKeys;
import net.vlp.cushion.CushionPlugin;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

/**
 * Отвечает за размещение Cushion в мире и его разрушение.
 *
 * Ключевая особенность (как в снапшотах 26.3): Cushion — это СУЩНОСТЬ,
 * а не блок из сетки. Поэтому она не привязана к координатам блока и её
 * можно поставить на любую высоту — ровно туда, куда игрок кликнул мышкой,
 * будь то верхняя ступенька лестницы, забор, половина блока и т.д.
 */
public final class PlacementListener implements Listener {

    private final CushionPlugin plugin;
    private final CushionKeys keys;
    private final CushionItemFactory items;

    public PlacementListener(CushionPlugin plugin) {
        this.plugin = plugin;
        this.keys = plugin.keys();
        this.items = plugin.itemFactory();
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != EquipmentSlot.HAND) return; // не обрабатываем оффхенд, чтобы не сработало дважды

        Player player = event.getPlayer();
        ItemStack inHand = event.getItem();
        if (!items.isCushionItem(inHand)) return;
        if (!player.hasPermission("vlp.cushion.place")) return;

        // Точная точка клика через ray trace — это и даёт эффект "любая высота,
        // подстройка под поверхность", а не просто "на верх блока".
        RayTraceResult trace = player.rayTraceBlocks(6.0, FluidCollisionMode.NEVER);
        if (trace == null || trace.getHitPosition() == null) return;

        Location spawnLocation = trace.getHitPosition().toLocation(player.getWorld());
        // Оставляем поворот нулевым: подушка всегда лежит ровно по осям мира,
        // а не под тем углом, под которым игрок на неё смотрел при установке.
        spawnLocation.setYaw(0f);
        spawnLocation.setPitch(0f);

        event.setCancelled(true);

        CushionItemFactory.CushionColor color = items.getColorFromItem(inHand);
        spawnCushionEntity(spawnLocation, color);

        if (player.getGameMode() != org.bukkit.GameMode.CREATIVE) {
            inHand.setAmount(inHand.getAmount() - 1);
        }

        player.getWorld().playSound(spawnLocation, Sound.BLOCK_WOOL_PLACE, 1f, 1f);
    }

    /**
     * Спавнит пару сущностей:
     *  - Interaction — невидимый "хитбокс" для регистрации кликов (у Display-сущностей
     *    по умолчанию нет хитбокса, поэтому клики на них не работают без Interaction);
     *  - ItemDisplay — визуальная модель подушки (ковёр), сплющенная и
     *    уменьшенная через Transformation, чтобы напоминать по силуэту подушку.
     */
    private void spawnCushionEntity(Location location, CushionItemFactory.CushionColor color) {
        Interaction interaction = (Interaction) location.getWorld().spawnEntity(location, EntityType.INTERACTION);
        interaction.setInteractionWidth(0.9f);
        interaction.setInteractionHeight(0.35f);
        interaction.setResponsive(true);
        interaction.getPersistentDataContainer().set(keys.entityMarker, PersistentDataType.BYTE, (byte) 1);
        interaction.getPersistentDataContainer().set(keys.entityColor, PersistentDataType.STRING, color.name());

        ItemDisplay display = (ItemDisplay) location.getWorld().spawnEntity(location, EntityType.ITEM_DISPLAY);
        display.setItemStack(new ItemStack(color.carpetMaterial));
        display.setBillboard(org.bukkit.entity.Display.Billboard.FIXED);
        // NONE — показывать модель как есть, без "иконочного" 3/4-разворота,
        // который движок применяет для GUI/рамок предметов (это и давало эффект
        // наклонённого "летающего ковра").
        display.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.NONE);

        Transformation transformation = new Transformation(
                // Item-модель блока по умолчанию центрирована на точке (от -0.5 до +0.5
                // по каждой оси). После сжатия по Y в 0.35 раза высота становится 0.35,
                // то есть половина (0.175) уходит НИЖЕ точки клика. Поднимаем модель на
                // эту половину + небольшой зазор, чтобы низ подушки совпадал с поверхностью,
                // на которую кликнул игрок, а не проваливался в неё.
                new Vector3f(0f, 0.19f, 0f),
                new AxisAngle4f(0f, 0f, 0f, 0f),               // без поворота — лежит ровно по осям мира
                new Vector3f(0.9f, 0.35f, 0.9f),               // сплющиваем по Y — силуэт подушки, а не полный ковёр
                new AxisAngle4f(0f, 0f, 0f, 0f)
        );
        display.setTransformation(transformation);
        display.setTeleportDuration(0);

        // Связываем визуал с хитбоксом: делаем display пассажиром interaction,
        // чтобы они всегда оставались в одной точке и synхронно исчезали.
        interaction.addPassenger(display);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Interaction interaction)) return;
        if (!interaction.getPersistentDataContainer().has(keys.entityMarker, PersistentDataType.BYTE)) return;
        if (!(event.getDamager() instanceof Player player)) return;
        if (!player.hasPermission("vlp.cushion.break")) {
            event.setCancelled(true);
            return;
        }

        event.setCancelled(true); // сами решаем судьбу сущности, ваниль тут ни при чём

        String colorName = interaction.getPersistentDataContainer()
                .get(keys.entityColor, PersistentDataType.STRING);
        CushionItemFactory.CushionColor color = colorName != null
                ? CushionItemFactory.CushionColor.valueOf(colorName)
                : CushionItemFactory.CushionColor.WHITE;

        // Если на подушке кто-то сидит — сначала снимаем.
        for (Entity passenger : interaction.getPassengers()) {
            if (passenger instanceof org.bukkit.entity.ArmorStand seat
                    && seat.getPersistentDataContainer().has(keys.seatMarker, PersistentDataType.BYTE)) {
                seat.eject();
                seat.remove();
            }
        }

        Location dropLocation = interaction.getLocation();
        interaction.getWorld().dropItemNaturally(dropLocation, plugin.itemFactory().createCushionItem(color, 1));
        interaction.getWorld().playSound(dropLocation, Sound.BLOCK_WOOL_BREAK, 1f, 1f);

        // Убираем всех пассажиров (визуальный display) и саму сущность.
        interaction.getPassengers().forEach(Entity::remove);
        interaction.remove();
    }
}
