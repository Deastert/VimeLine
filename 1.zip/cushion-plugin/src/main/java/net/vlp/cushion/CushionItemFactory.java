package net.vlp.cushion;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/**
 * Отвечает за создание предмета "Cushion" (подушки) и регистрацию рецептов
 * для всех 16 цветов шерсти, аналогично тому, как это описано в снапшотах 26.3:
 * 3 ковра одного цвета -> 1 Cushion этого цвета.
 */
public final class CushionItemFactory {

    /** Все цвета ковров/подушек, как в ванильном Minecraft. */
    public enum CushionColor {
        WHITE(Material.WHITE_CARPET, NamedTextColor.WHITE),
        ORANGE(Material.ORANGE_CARPET, NamedTextColor.GOLD),
        MAGENTA(Material.MAGENTA_CARPET, NamedTextColor.LIGHT_PURPLE),
        LIGHT_BLUE(Material.LIGHT_BLUE_CARPET, NamedTextColor.AQUA),
        YELLOW(Material.YELLOW_CARPET, NamedTextColor.YELLOW),
        LIME(Material.LIME_CARPET, NamedTextColor.GREEN),
        PINK(Material.PINK_CARPET, NamedTextColor.LIGHT_PURPLE),
        GRAY(Material.GRAY_CARPET, NamedTextColor.DARK_GRAY),
        LIGHT_GRAY(Material.LIGHT_GRAY_CARPET, NamedTextColor.GRAY),
        CYAN(Material.CYAN_CARPET, NamedTextColor.DARK_AQUA),
        PURPLE(Material.PURPLE_CARPET, NamedTextColor.DARK_PURPLE),
        BLUE(Material.BLUE_CARPET, NamedTextColor.BLUE),
        BROWN(Material.BROWN_CARPET, NamedTextColor.DARK_RED),
        GREEN(Material.GREEN_CARPET, NamedTextColor.DARK_GREEN),
        RED(Material.RED_CARPET, NamedTextColor.RED),
        BLACK(Material.BLACK_CARPET, NamedTextColor.BLACK);

        public final Material carpetMaterial;
        public final NamedTextColor textColor;

        CushionColor(Material carpetMaterial, NamedTextColor textColor) {
            this.carpetMaterial = carpetMaterial;
            this.textColor = textColor;
        }
    }

    private final CushionPlugin plugin;
    private final CushionKeys keys;

    public CushionItemFactory(CushionPlugin plugin) {
        this.plugin = plugin;
        this.keys = plugin.keys();
    }

    /**
     * Создаёт предмет Cushion указанного цвета.
     * Визуально — ковёр (пока нет официальной модели из 26.3),
     * но помечена как отдельный предмет через PersistentDataContainer,
     * так что не путается с обычными коврами в инвентаре/крафтах.
     */
    public ItemStack createCushionItem(CushionColor color, int amount) {
        ItemStack item = new ItemStack(color.carpetMaterial, amount);
        ItemMeta meta = item.getItemMeta();

        meta.displayName(Component.text("Подушка (" + colorNameRu(color) + ")", color.textColor)
                .decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("ПКМ по блоку — разместить", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("ПКМ по подушке — сесть", NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(lore);

        meta.getPersistentDataContainer().set(keys.itemMarker, PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(keys.itemColor, PersistentDataType.STRING, color.name());

        item.setItemMeta(meta);
        return item;
    }

    /** Проверяет, является ли ItemStack предметом Cushion. */
    public boolean isCushionItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer()
                .has(keys.itemMarker, PersistentDataType.BYTE);
    }

    /** Достаёт цвет из предмета Cushion. Возвращает WHITE, если что-то пошло не так. */
    public CushionColor getColorFromItem(ItemStack item) {
        String raw = item.getItemMeta().getPersistentDataContainer()
                .get(keys.itemColor, PersistentDataType.STRING);
        if (raw == null) return CushionColor.WHITE;
        try {
            return CushionColor.valueOf(raw);
        } catch (IllegalArgumentException e) {
            return CushionColor.WHITE;
        }
    }

    private String colorNameRu(CushionColor color) {
        return switch (color) {
            case WHITE -> "Белая";
            case ORANGE -> "Оранжевая";
            case MAGENTA -> "Пурпурная";
            case LIGHT_BLUE -> "Голубая";
            case YELLOW -> "Жёлтая";
            case LIME -> "Лаймовая";
            case PINK -> "Розовая";
            case GRAY -> "Серая";
            case LIGHT_GRAY -> "Светло-серая";
            case CYAN -> "Бирюзовая";
            case PURPLE -> "Фиолетовая";
            case BLUE -> "Синяя";
            case BROWN -> "Коричневая";
            case GREEN -> "Зелёная";
            case RED -> "Красная";
            case BLACK -> "Чёрная";
        };
    }

    /** Регистрирует бесформенные рецепты крафта для всех 16 цветов: 3 ковра -> 1 Cushion. */
    public void registerRecipes() {
        for (CushionColor color : CushionColor.values()) {
            NamespacedKey recipeKey = new NamespacedKey(plugin, "cushion_recipe_" + color.name().toLowerCase());
            ShapelessRecipe recipe = new ShapelessRecipe(recipeKey, createCushionItem(color, 1));
            recipe.addIngredient(3, color.carpetMaterial);
            plugin.getServer().addRecipe(recipe);
        }
    }
}
