package net.vlp.cushion.listeners;

import net.vlp.cushion.CushionKeys;
import net.vlp.cushion.CushionPlugin;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDismountEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.persistence.PersistentDataType;

/**
 * Отвечает за само "сидение": по ПКМ на Cushion игрок садится, по слезанию
 * (шифт, прыжок, дальность) — сидение-невидимка убирается.
 *
 * Технически посадка реализована через невидимый marker ArmorStand:
 * такой ArmorStand не имеет коллизии и хитбокса, но может быть "транспортом"
 * (vehicle) для игрока — это стандартный, проверенный годами приём для
 * посадочных механик на Paper/Spigot серверах.
 */
public final class SeatListener implements Listener {

    private final CushionPlugin plugin;
    private final CushionKeys keys;

    public SeatListener(CushionPlugin plugin) {
        this.plugin = plugin;
        this.keys = plugin.keys();
    }

    @EventHandler(ignoreCancelled = true)
    public void onSit(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof Interaction interaction)) return;
        if (!interaction.getPersistentDataContainer().has(keys.entityMarker, PersistentDataType.BYTE)) return;

        Player player = event.getPlayer();
        if (!player.hasPermission("vlp.cushion.sit")) return;
        if (player.isInsideVehicle()) return; // уже где-то сидит/едет

        // Если на этой подушке уже кто-то сидит — не сажаем второго.
        for (Entity passenger : interaction.getPassengers()) {
            if (passenger instanceof ArmorStand seat
                    && seat.getPersistentDataContainer().has(keys.seatMarker, PersistentDataType.BYTE)
                    && !seat.getPassengers().isEmpty()) {
                return;
            }
        }

        event.setCancelled(true);

        ArmorStand seat = interaction.getWorld().spawn(interaction.getLocation(), ArmorStand.class, stand -> {
            stand.setInvisible(true);
            stand.setInvulnerable(true);
            stand.setMarker(true);       // без хитбокса и коллизии
            stand.setGravity(false);
            stand.setSilent(true);
            stand.setBasePlate(false);
            stand.setPersistent(false);  // временная сущность, живёт пока кто-то сидит
            stand.getPersistentDataContainer().set(keys.seatMarker, PersistentDataType.BYTE, (byte) 1);
            stand.getPersistentDataContainer().set(keys.seatOwnerUuid, PersistentDataType.STRING,
                    interaction.getUniqueId().toString());
        });

        interaction.addPassenger(seat);
        seat.addPassenger(player);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDismount(EntityDismountEvent event) {
        if (!(event.getDismounted() instanceof ArmorStand seat)) return;
        if (!seat.getPersistentDataContainer().has(keys.seatMarker, PersistentDataType.BYTE)) return;

        // Убираем сидение на следующий тик, чтобы не мешать самому событию слезания.
        seat.getScheduler().run(plugin,
                task -> {
                    seat.leaveVehicle();
                    seat.remove();
                },
                null);
    }
}
