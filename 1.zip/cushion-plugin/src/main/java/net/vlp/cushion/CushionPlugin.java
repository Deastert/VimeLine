package net.vlp.cushion;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.vlp.cushion.listeners.CleanupListener;
import net.vlp.cushion.listeners.PlacementListener;
import net.vlp.cushion.listeners.SeatListener;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public final class CushionPlugin extends JavaPlugin {

    private CushionKeys keys;
    private CushionItemFactory itemFactory;

    @Override
    public void onEnable() {
        this.keys = new CushionKeys(this);
        this.itemFactory = new CushionItemFactory(this);

        itemFactory.registerRecipes();

        getServer().getPluginManager().registerEvents(new PlacementListener(this), this);
        getServer().getPluginManager().registerEvents(new SeatListener(this), this);
        getServer().getPluginManager().registerEvents(new CleanupListener(this), this);

        getLogger().info("VLP-Cushion включён: механика сидушек активна.");
    }

    @Override
    public void onDisable() {
        getLogger().info("VLP-Cushion выключен.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("cushion")) return false;

        if (args.length < 1) {
            sender.sendMessage(Component.text("Использование: /cushion <цвет> [игрок]", NamedTextColor.RED));
            return true;
        }

        CushionItemFactory.CushionColor color;
        try {
            color = CushionItemFactory.CushionColor.valueOf(args[0].toUpperCase());
        } catch (IllegalArgumentException e) {
            sender.sendMessage(Component.text("Неизвестный цвет. Доступные: white, orange, magenta, light_blue, " +
                    "yellow, lime, pink, gray, light_gray, cyan, purple, blue, brown, green, red, black", NamedTextColor.RED));
            return true;
        }

        Player target;
        if (args.length >= 2) {
            target = getServer().getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(Component.text("Игрок не найден или не в сети.", NamedTextColor.RED));
                return true;
            }
        } else if (sender instanceof Player p) {
            target = p;
        } else {
            sender.sendMessage(Component.text("Укажи игрока, если выполняешь команду из консоли.", NamedTextColor.RED));
            return true;
        }

        ItemStack item = itemFactory.createCushionItem(color, 1);
        target.getInventory().addItem(item);
        sender.sendMessage(Component.text("Выдана подушка (" + color.name() + ") игроку " + target.getName(), NamedTextColor.GREEN));
        return true;
    }

    public CushionKeys keys() {
        return keys;
    }

    public CushionItemFactory itemFactory() {
        return itemFactory;
    }
}
