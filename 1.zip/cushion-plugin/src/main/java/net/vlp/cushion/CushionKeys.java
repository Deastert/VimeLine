package net.vlp.cushion;

import org.bukkit.NamespacedKey;
import org.bukkit.plugin.Plugin;

/**
 * Централизованное хранилище NamespacedKey, которые используются
 * для маркировки предметов и сущностей плагина через PersistentDataContainer.
 */
public final class CushionKeys {

    public final NamespacedKey itemMarker;      // метка на ItemStack: "это предмет Cushion"
    public final NamespacedKey itemColor;       // цвет предмета (строка, например "RED")
    public final NamespacedKey entityMarker;    // метка на Interaction: "это размещённый Cushion"
    public final NamespacedKey entityColor;     // цвет размещённого Cushion
    public final NamespacedKey activeSeatUuid;  // UUID активного ArmorStand-сидения (если сейчас занято)
    public final NamespacedKey seatMarker;      // метка на ArmorStand: "это сидение Cushion"
    public final NamespacedKey seatOwnerUuid;   // UUID Interaction-сущности, которой принадлежит сидение

    public CushionKeys(Plugin plugin) {
        this.itemMarker = new NamespacedKey(plugin, "cushion_item");
        this.itemColor = new NamespacedKey(plugin, "cushion_item_color");
        this.entityMarker = new NamespacedKey(plugin, "cushion_entity");
        this.entityColor = new NamespacedKey(plugin, "cushion_entity_color");
        this.activeSeatUuid = new NamespacedKey(plugin, "cushion_active_seat");
        this.seatMarker = new NamespacedKey(plugin, "cushion_seat");
        this.seatOwnerUuid = new NamespacedKey(plugin, "cushion_seat_owner");
    }
}
