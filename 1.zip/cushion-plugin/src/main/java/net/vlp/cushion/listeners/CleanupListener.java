package net.vlp.cushion.listeners;

import net.vlp.cushion.CushionKeys;
import net.vlp.cushion.CushionPlugin;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.persistence.PersistentDataType;

/**
 * Подчищает "сидение" (ArmorStand-marker), если игрок вышел с сервера,
 * пока сидел на подушке — иначе невидимая сущность-сидение осталась бы
 * висеть в мире без пассажира.
 */
public final class CleanupListener implements Listener {

    private final CushionKeys keys;

    public CleanupListener(CushionPlugin plugin) {
        this.keys = plugin.keys();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Entity vehicle = event.getPlayer().getVehicle();
        if (vehicle instanceof ArmorStand seat
                && seat.getPersistentDataContainer().has(keys.seatMarker, PersistentDataType.BYTE)) {
            seat.eject();
            seat.remove();
        }
    }
}
